#!/usr/bin/python
#config file containing credentials for rds mysql instance

db_username = "incedoadmin"
db_password = "incedoadmin"
db_name = "motovibr"
db_endpoint = "databaseinstance.crou4qtxtjum.ap-southeast-2.rds.amazonaws.com"
